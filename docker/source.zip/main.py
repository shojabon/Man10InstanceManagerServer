from Man10InstanceManager import Man10InstanceManager

if __name__ == '__main__':
    i = Man10InstanceManager()
